$(document).ready(function(){
  $('input').mlKeyboard();
});
