$('#mainTable').editableTableWidget().numericInputExample().find('td:first').focus();
$('#textAreaEditor').editableTableWidget({editor: $('<textarea>')});