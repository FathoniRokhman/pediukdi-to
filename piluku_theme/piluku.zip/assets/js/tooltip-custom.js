$('document').ready(function(){
    $("a").tooltip();
    
    $("[data-toggle=popover]").popover();
});